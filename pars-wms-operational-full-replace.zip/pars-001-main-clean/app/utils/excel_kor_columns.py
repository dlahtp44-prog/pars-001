from typing import Dict, List, Tuple

# =====================================================
# 엑셀 한글 컬럼 정의
# - 수량만 필수
# =====================================================

# 🔥 필수 컬럼
REQUIRED = ["수량"]

# ⭕ 선택 컬럼 (있으면 사용)
OPTIONAL = [
    "입고일",    # 입고 엑셀 날짜
    "출고일",    # 출고 엑셀 날짜
    "창고",
    "로케이션",
    "브랜드",
    "품번",
    "품명",
    "LOT",
    "규격",
    "비고",
]


# =====================================================
# 헤더 정규화
# =====================================================

def normalize_header(s: str) -> str:
    if s is None:
        return ""

    s = str(s).strip()
    s = s.replace(" ", "")

    mapping = {
        # 날짜
        "입고일": "입고일",
        "출고일": "출고일",
        "DATE": "입고일",      # 공통 DATE → 입고일 기준
        "Date": "입고일",
        "날짜": "입고일",

        # 창고
        "창고": "창고",
        "WAREHOUSE": "창고",
        "Warehouse": "창고",

        # 로케이션
        "로케이션": "로케이션",
        "LOCATION": "로케이션",
        "Loc": "로케이션",

        # 브랜드
        "브랜드": "브랜드",
        "BRAND": "브랜드",
        "Brand": "브랜드",

        # 품번 / 품명
        "품번": "품번",
        "ITEMCODE": "품번",
        "ItemCode": "품번",

        "품명": "품명",
        "ITEMNAME": "품명",
        "ItemName": "품명",

        # LOT / 규격
        "LOT": "LOT",
        "Lot": "LOT",

        "규격": "규격",
        "SPEC": "규격",
        "Spec": "규격",

        # 수량
        "수량": "수량",
        "QTY": "수량",
        "Qty": "수량",
        "수량(PCS)": "수량",

        # 비고
        "비고": "비고",
        "NOTE": "비고",
        "Note": "비고",
    }

    return mapping.get(s, s)


# =====================================================
# 컬럼 인덱스 빌드
# =====================================================

def build_col_index(headers: List[str]) -> Dict[str, int]:
    idx: Dict[str, int] = {}

    for i, h in enumerate(headers):
        nh = normalize_header(h)
        if nh and nh not in idx:
            idx[nh] = i

    return idx


# =====================================================
# 필수 컬럼 검증
# =====================================================

def validate_required(idx: Dict[str, int]) -> Tuple[bool, List[str]]:
    missing = [c for c in REQUIRED if c not in idx]
    return (len(missing) == 0, missing)
